&#x20;✨ BRAINOVA - A GAMIFIED STUDY TRACKING WEBSITE



A modern, AI-powered \*\*gamified study tracking website built with Streamlit. This project helps you build and maintain positive habits, track your progress, and stay motivated with smart suggestions and analytics.



🚀 Features



\* 📝 \*\*Reminders\*\*: Set and manage sticky reminders for non-habit tasks (e.g., "Call Mom", "Pay Bills").

\* 📅 \*\*Daily Focus\*\*: See your habits for today, mark them as done, and get a sense of accomplishment.

\* 💡 \*\*Smart Suggestions\*\*: AI-driven recommendations to help you stay on track and improve your routines.

\* 📊 \*\*Analytics\*\*: Visualize your habit streaks, completion rates, and progress over time.

\* ⚙️ \*\*Settings\*\*: Edit or delete habits, manage your data, and customize your experience.

\* 🔔 \*\*Priority Levels\*\*: Color-coded reminders for high, medium, and low priority tasks.

\* 🎨 \*\*Beautiful UI\*\*: Custom CSS for a modern, visually appealing experience.



&#x20;🛠️ Tech Stack



\* \[Streamlit](https://streamlit.io/) for the interactive web UI

\* \[Pandas](https://pandas.pydata.org/) for data management

\* Custom Python modules for database, analytics, ML logic, and UI components



&#x20;📂 Project Structure





app.py                  # Main Brainova app

requirements.txt        # Python dependencies

config/                 # Configuration files

src/

&#x20; analytics.py          # Analytics and visualization logic

&#x20; data\_manager.py       # Data loading and saving

&#x20; database.py           # Database initialization and helpers

&#x20; ml\_logic.py           # AI/machine learning logic

&#x20; ui\_components.py      # Custom UI elements

&#x20; utils.py              # Utility functions





&#x20;🏁 Getting Started



1\. Clone the repository



bash

\&#x20;  git clone https://github.com/your-username/brainova.git

\&#x20;  cd brainova

\&#x20;  



2. Install dependencies



bash

\&#x20;  pip install -r requirements.txt

\&#x20; 



3. Run the app



bash

\&#x20;  streamlit run app.py

\&#x20;  



🤖 AI \\\& Smart Features



\\\* Brainova uses simple ML logic to provide motivational messages and habit suggestions based on your activity.

\\\* All analytics and suggestions run locally—no data leaves your machine!



\\## 📢 Contributing



Pull requests are welcome! For major changes, please open an issue first to discuss what you would like to change.



\\## 🛡️ License



This project is private and for personal or internal use only.



\\---



Made with ❤️ by Project Maker






